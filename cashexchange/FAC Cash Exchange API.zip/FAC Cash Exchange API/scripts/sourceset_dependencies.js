sourceset_dependencies = '{":middleware:dokkaHtml/main": []}'
